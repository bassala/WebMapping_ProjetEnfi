from django.contrib import admin
from .models import A,B,C,D,E


admin.site.register(A)


admin.site.register(B)


admin.site.register(C)


admin.site.register(D)


admin.site.register(E)
